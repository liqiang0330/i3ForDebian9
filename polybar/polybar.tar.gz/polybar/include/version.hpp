#pragma once

#define GIT_TAG "3.1.0"
#define GIT_TAG_NAMESPACE v3_1_0
