### 0.9.3

  - got rid of slow named color regular expression to speed things up
  - fixed the issue of plugin being slow when switching buffers(issue #13)

### 0.9.1

  - fixed bug #7 "Do not trigger on CSS property names"
  - fixed bug #11 "hlsearch colors hidden by coloresque colors"
  - merged hex and hex3 handlers
